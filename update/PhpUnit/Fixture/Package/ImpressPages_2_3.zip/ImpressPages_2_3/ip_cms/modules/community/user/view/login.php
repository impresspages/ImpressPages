<?php echo $this->renderWidget('IpTitle', array('title' => $this->par('community/user/translations/title_login'))); ?>
<?php echo $this->renderWidget('IpUserLogin'); ?>
