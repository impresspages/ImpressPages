

function installTheme(e) {
    e.preventDefault();
    
    
}