<?php
/* Default style is the same as level1 */
echo \Ip\View::create('level1.php', $this->getData())->render();
?>
