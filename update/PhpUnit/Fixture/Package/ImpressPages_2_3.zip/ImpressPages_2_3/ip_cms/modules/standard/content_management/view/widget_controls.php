<div class="ipAdminWidgetControls">
    <a href="#" class="ipaButton ipActionWidgetManage"><span>Edit</span></a>
    <a href="#" class="ipaButton ipActionWidgetMove"><span>Move</span></a>
    <a href="#" class="ipaButton ipActionWidgetDelete"><span>Delete</span></a>
</div>
<div class="ipAdminWidgetMoveIcon"></div>