<div style="display: none;" id="ipSaveProgress">
    <div class="ipMainProgressbar"></div>
    Progress
</div>
