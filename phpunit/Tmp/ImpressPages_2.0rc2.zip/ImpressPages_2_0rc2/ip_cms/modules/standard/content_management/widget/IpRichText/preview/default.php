<?php echo isset($text) ? $text : ''; ?>
