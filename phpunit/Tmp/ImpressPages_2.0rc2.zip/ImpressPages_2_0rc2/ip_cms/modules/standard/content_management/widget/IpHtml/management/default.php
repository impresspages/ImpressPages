<textarea name="text" class="ipAdminTextarea"><?php echo isset($html) ? $html : ''; ?></textarea>
