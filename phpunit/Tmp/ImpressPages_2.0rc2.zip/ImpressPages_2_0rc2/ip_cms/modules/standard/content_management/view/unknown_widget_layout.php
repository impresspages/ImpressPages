<?php echo $this->par('standard/content_management/admin_translations/missing_layout', array('layout' => $layout, 'widgetName' => $widgetName)) ?>
