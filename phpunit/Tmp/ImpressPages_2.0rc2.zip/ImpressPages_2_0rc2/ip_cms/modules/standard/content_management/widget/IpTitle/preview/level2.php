<h2 class="ipwTitle"><?php echo htmlspecialchars(isset($title) ? $title : '' ); ?></h2>
