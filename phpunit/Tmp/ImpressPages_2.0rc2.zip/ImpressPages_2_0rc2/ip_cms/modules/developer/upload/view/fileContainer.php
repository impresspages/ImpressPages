<a href="#" class="ipAdminButton ipUploadBrowseButton">Add new</a>
