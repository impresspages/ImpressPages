<?php if ($loggedIn) {?>
    <?php echo $profileForm->render(); ?>
<?php } ?>