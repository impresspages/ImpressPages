<?php echo $this->renderWidget('IpTitle', array('title' => $this->par('community/user/translations/title_password_reset'))); ?>
<?php echo $this->renderWidget('IpText', array('text' => $this->par('community/user/translations/text_password_verified'))); ?>
<?php echo $this->renderWidget('IpUserLogin'); ?>