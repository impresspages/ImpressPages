<?php echo $this->create(BASE_DIR.MODULE_DIR.'standard/configuration/view/email.php', $this->getData()); ?>
