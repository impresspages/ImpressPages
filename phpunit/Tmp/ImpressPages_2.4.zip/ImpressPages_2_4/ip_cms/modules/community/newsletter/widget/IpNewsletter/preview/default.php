<?php 
echo $form->render();
?>
<?php 
/*global $site;
$zone = $site->getZoneByModule('community', 'newsletter');
if ($zone) {
    
    echo $zone->generateRegistrationBox();
    
} else {
    echo 'Please create newsletter zone';
}
*/
?>