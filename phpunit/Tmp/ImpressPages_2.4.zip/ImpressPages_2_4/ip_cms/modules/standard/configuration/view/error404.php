<?php echo $this->renderWidget('IpTitle', array('title' => $title)); ?>
<?php echo $this->renderWidget('IpText', array('text' => $text)); ?>