<textarea name="text">
<?php echo isset($text) ? $text : '' ?>
</textarea>
