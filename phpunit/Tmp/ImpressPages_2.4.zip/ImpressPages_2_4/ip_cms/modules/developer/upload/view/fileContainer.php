<div class="ipUploadProgressContainer"></div>
<div class="ipUploadProgressItemSample ipgHide">
    <div class="ipUploadProgressItem">
        <div class="ipUploadProgressbar"></div>
        <p class="ipUploadTitle"></p>
    </div>
</div>
<a href="#" class="ipAdminButton ipUploadBrowseButton">Add new</a>
