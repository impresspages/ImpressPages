<div class="ipUploadWindow ui-widget-content">
    <div class="ipUploadButtons">
        <div class="ipUploadBrowseContainer">
            <a href="#" class="ipUploadImageButton ipUploadBrowseButton">Upload new</a>
        </div>
        <a href="#" class="ipUploadImageButton ipUploadLargerButton">Larger</a>
        <a href="#" class="ipUploadImageButton ipUploadSmallerButton">Smaller</a>
    </div>
    <div class="ipUploadProgressbar"></div>
    <div class="ipUploadDragContainer">
        <img class="ipUploadImage" src="<?php echo BASE_URL.MODULE_DIR ?>developer/upload/img/empty.gif" alt="image" />
    </div>
</div>
