<?php

 if(!isset($_GET['install']))
    header("location: install/?install=1");