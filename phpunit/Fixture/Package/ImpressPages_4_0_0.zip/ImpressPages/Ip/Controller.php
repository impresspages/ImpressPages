<?php
/**
 * @package ImpressPages
 *
 *
 */

namespace Ip;


/**
 * General MVC Controller
 *
 * Every plugin controller (public, site or administration controller) must extend this class.
 */
class Controller{

}