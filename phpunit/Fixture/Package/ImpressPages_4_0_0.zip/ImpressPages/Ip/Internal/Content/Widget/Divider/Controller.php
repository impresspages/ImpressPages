<?php
/**
 * @package ImpressPages

 *
 */
namespace Ip\Internal\Content\Widget\Divider;




class Controller extends \Ip\WidgetController{


    public function getTitle() {
        return __('Divider', 'ipAdmin', false);
    }

}
