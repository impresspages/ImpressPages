<?php echo __('Unknown widget.', 'ipAdmin') ?>
