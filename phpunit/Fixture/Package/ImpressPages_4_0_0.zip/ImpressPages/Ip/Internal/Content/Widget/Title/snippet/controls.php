<div class="ip">
    <div class="hidden" id="ipWidgetTitleControls">
        <div class="btn-toolbar" role="toolbar">
            <div class="btn-group">
                <button type="button" data-level="1" class="btn btn-default ipsH"><?php _e('H1', 'ipAdmin') ?></button>
                <button type="button" data-level="2" class="btn btn-default ipsH"><?php _e('H2', 'ipAdmin') ?></button>
                <button type="button" data-level="3" class="btn btn-default ipsH"><?php _e('H3', 'ipAdmin') ?></button>
                <button type="button" class="btn btn-default ipsOptions"><?php _e('Options', 'ipAdmin') ?></button>
            </div>
        </div>
    </div>
</div>
