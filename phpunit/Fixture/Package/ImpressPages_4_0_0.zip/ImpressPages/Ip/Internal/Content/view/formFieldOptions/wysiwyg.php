<div class="ipsFieldOptionsRichText"></div>
<?php echo $form->render() ?>
