<div class="ipsContainer">
    <?php echo !empty($text) ? $text : '&nbsp;'; ?>
</div>
