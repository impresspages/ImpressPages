<div class="ipUploadProgressContainer"></div>
<div class="ipUploadProgressItemSample hidden">
    <div class="ipUploadProgressItem">
        <div class="ipUploadProgressbar"></div>
        <p class="ipUploadTitle"></p>
    </div>
</div>
<a href="#" class="ipAdminButton ipUploadBrowseButton"><?php _e('Add new', 'ipAdmin'); ?></a>
