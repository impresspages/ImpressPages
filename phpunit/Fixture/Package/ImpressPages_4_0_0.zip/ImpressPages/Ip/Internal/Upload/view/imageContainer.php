<div class="ipUploadWindow">
    <div class="ipUploadButtons">
        <div class="ipUploadBrowseContainer">
            <a href="#" class="ipUploadImageButton ipUploadBrowseButton" title="<?php _e('Upload new', 'ipAdmin'); ?>"></a>
        </div>
        <a href="#" class="ipUploadImageButton ipUploadLargerButton" title="<?php _e('Zoom in', 'ipAdmin'); ?>"></a>
        <a href="#" class="ipUploadImageButton ipUploadSmallerButton" title="<?php _e('Zoom out', 'ipAdmin'); ?>"></a>
    </div>
    <div class="ipUploadDragContainer">
        <img class="ipUploadImage" src="<?php echo ipFileUrl('Ip/Internal/Upload/assets/empty.gif') ?>" alt="" />
    </div>
</div>
