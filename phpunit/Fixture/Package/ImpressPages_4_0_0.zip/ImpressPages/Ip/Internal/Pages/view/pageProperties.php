<div class="page-header">
    <h1><?php _e('Page properties', 'ipAdmin') ?></h1>
</div>
<div class="_actions clearfix">
    <button class="ipsDelete btn btn-danger pull-right" role="button"><?php _e('Delete', 'ipAdmin'); ?><i class="fa fa-fw fa-trash-o"></i></button>
    <button class="ipsEdit btn btn-primary" role="button"><?php _e('Edit Content', 'ipAdmin'); ?> <i class="fa fa-fw fa-edit"></i></button>
</div>
<?php echo $form->render(); ?>
