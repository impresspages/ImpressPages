<p><?php _e('To reset your password follow the link below:', 'ipAdmin') ?></p>

<a href="<?php echo $link ?>"><?php echo esc($link) ?></a>

<p><?php _e('You will then be able to reset your password.', 'ipAdmin') ?></p>
