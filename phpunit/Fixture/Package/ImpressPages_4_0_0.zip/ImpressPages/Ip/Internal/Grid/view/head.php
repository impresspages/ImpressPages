<?php if (!empty($title)) { ?>
<h1><?php echo esc($title) ?></h1>
<?php } ?>