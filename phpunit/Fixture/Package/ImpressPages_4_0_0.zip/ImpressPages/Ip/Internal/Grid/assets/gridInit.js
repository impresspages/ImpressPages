/**
 * @package ImpressPages
 *
 *
 */

(function ($) {
    "use strict";
    $(document).ready(function () {
        $('.ipsGrid').ipGrid();
    });

})(ip.jQuery);
