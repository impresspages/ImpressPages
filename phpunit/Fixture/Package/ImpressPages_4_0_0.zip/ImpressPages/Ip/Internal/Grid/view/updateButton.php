<button type="button" class="btn btn-default ipsUpdate" title="<?php _e('Edit', 'ipAdmin'); ?>"><i class="fa fa-edit"></i></button>
