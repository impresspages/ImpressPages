<button type="button" class="btn btn-default ipsDrag" title="<?php _e('Drag', 'ipAdmin'); ?>"><i class="fa fa-arrows"></i></button>
