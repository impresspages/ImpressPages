<button type="button" class="btn btn-danger ipsDelete"><?php _e('Delete', 'ipAdmin'); ?><i class="fa fa-fw fa-trash-o"></i></button>
