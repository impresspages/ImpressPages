<div class="ipModuleGrid ipsGrid" data-gateway="<?php echo esc(json_encode($gateway), 'attr'); ?>"></div>
