<div class="ip">
    <div class="ipModuleInlineManagementControls ipsModuleInlineManagementControls">
        <div class="ipAdminWidgetControls">
            <div class="_controls clearfix">
                <button class="btn btn-controls btn-xs _settings ipActionWidgetManage" data-toggle="dropdown" title="<?php _e('Edit', 'ipAdmin'); ?>"><i class="fa fa-cog"></i></button>
            </div>
        </div>
    </div>
</div>
