/**
 * @package ImpressPages
 *
 */

(function($){
    "use strict";

    $(document).ready(function () {
        //$('.ipModuleInlineManagement').ipModuleInlineManagement();
        $('.ipsModuleInlineManagementLogo').ipModuleInlineManagementLogo();
        $('.ipsModuleInlineManagementText').ipModuleInlineManagementText();
        $('.ipsModuleInlineManagementImage').ipModuleInlineManagementImage();
    });
})(ip.jQuery);
