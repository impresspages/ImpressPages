(function($){
    "use strict";

    $(document).ready(function() {

        $('.ipmControlInput').first().focus();

    });

})(ip.jQuery);
