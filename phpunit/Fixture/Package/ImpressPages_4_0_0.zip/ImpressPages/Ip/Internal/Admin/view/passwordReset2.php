<div class="loginTitle">
    <h1><?php _e('Password reset', 'ipAdmin'); ?></h1>
</div>
<div class="ip loginContent">
    <p><?php _e('Please enter your new password', 'ipAdmin'); ?></p>
    <?php echo $passwordResetForm->render(); ?>
</div>
