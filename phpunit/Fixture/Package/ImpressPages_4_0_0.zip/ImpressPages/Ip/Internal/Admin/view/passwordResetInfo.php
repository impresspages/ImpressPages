<div class="loginTitle">
    <h1><?php _e('Password reset', 'ipAdmin'); ?></h1>
</div>
<div class="ip loginContent">
    <p><?php _e('You will receive an e-mail with password reset link. Please follow the link and enter a new password.', 'ipAdmin'); ?></p>
</div>
