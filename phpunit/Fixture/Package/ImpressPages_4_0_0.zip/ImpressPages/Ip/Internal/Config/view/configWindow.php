<h1><?php _e('Configuration', 'ipAdmin') ?></h1>
<?php echo $form->render() ?>