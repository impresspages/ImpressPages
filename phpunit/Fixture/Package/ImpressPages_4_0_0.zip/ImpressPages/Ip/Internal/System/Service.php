<?php


namespace Ip\Internal\System;


class Service
{
    public static function cacheClear()
    {
        Model::cacheClear();
    }
}
