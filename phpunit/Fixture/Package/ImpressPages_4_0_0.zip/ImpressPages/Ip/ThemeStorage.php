<?php

namespace Ip;


class ThemeStorage extends \Ip\Internal\ValueStorage
{
    protected $tableName = 'themeStorage';
    protected $namespaceColumn = 'theme';
}
