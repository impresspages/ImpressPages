<?php


namespace Ip\Exception;


class Revision extends \Ip\Exception {}