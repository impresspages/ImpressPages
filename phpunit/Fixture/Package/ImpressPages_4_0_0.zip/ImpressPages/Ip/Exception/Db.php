<?php

namespace Ip\Exception;

class Db extends \Ip\Exception {}