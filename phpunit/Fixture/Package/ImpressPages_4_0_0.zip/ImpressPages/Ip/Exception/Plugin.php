<?php


namespace Ip\Exception;


class Plugin extends \Ip\Exception {}