<?php


namespace Ip;


class PageStorage extends \Ip\Internal\ValueStorage
{
    protected $tableName = 'pageStorage';
    protected $namespaceColumn = 'pageId';
}
